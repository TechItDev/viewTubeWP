(function($) {
  "use strict";
  	jQuery(document).ready(function($){
	  $('.vt-datetime').datepicker({
		  dateFormat : 'yy-mm-dd'
	  });
	});
})(jQuery);