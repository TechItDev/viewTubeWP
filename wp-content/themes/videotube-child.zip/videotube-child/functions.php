<?php
/**
 * write your functions here.
 */
if( ! defined('ABSPATH') ) exit;

add_action( 'wp_enqueue_scripts', 'videotube_child_enqueue_styles' );
add_action( 'login_enqueue_scripts', 'videotube_child_enqueue_styles' );

function videotube_child_enqueue_styles() {
	wp_enqueue_style( 
		'videotube-child-style', 
		get_stylesheet_uri(),
	    array( 'videotube-style' ), 
	    filemtime( get_stylesheet_directory() . '/style.css' )
	);
}
