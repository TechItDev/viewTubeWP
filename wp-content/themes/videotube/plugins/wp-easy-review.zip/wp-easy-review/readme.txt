WP Reviews V1.0

Changelogs:
Initial version.